// Data kontak disimpan di memori
let contacts = [];

const contactForm = document.getElementById('contactForm');
const namaInput = document.getElementById('nama');
const emailInput = document.getElementById('email');
const hpInput = document.getElementById('hp');
const tableBody = document.getElementById('tableBody');
const totalCountElement = document.getElementById('totalCount');

// Event listeners
contactForm.addEventListener('submit', handleAddContact);

// Validasi dan tambah kontak
function handleAddContact(e) {
    e.preventDefault();

    // Clear previous error messages
    clearErrors();

    // Get input values
    const nama = namaInput.value.trim();
    const email = emailInput.value.trim();
    const hp = hpInput.value.trim();

    // Validasi
    const isValid = validateForm(nama, email, hp);

    if (isValid) {
        // Tambah ke array kontak
        contacts.push({ nama, email, hp });

        // Update tabel
        renderTable();

        // Clear form
        contactForm.reset();
        namaInput.focus();
    }
}

// Validasi form
function validateForm(nama, email, hp) {
    let isValid = true;

    // Validasi Nama
    if (!nama) {
        showError('namaError', 'Nama tidak boleh kosong');
        namaInput.classList.add('error');
        isValid = false;
    }

    // Validasi Email
    if (!email) {
        showError('emailError', 'Email tidak boleh kosong');
        emailInput.classList.add('error');
        isValid = false;
    } else if (!isValidEmail(email)) {
        showError('emailError', 'Format email tidak valid (harus mengandung @ dan .)');
        emailInput.classList.add('error');
        isValid = false;
    }

    // Validasi No. HP
    if (!hp) {
        showError('hpError', 'No. HP tidak boleh kosong');
        hpInput.classList.add('error');
        isValid = false;
    } else if (!isValidHP(hp)) {
        showError('hpError', 'No. HP hanya boleh berisi angka dan minimal 10 digit');
        hpInput.classList.add('error');
        isValid = false;
    }

    return isValid;
}

// Cek format email
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Cek format HP
function isValidHP(hp) {
    const hpRegex = /^\d{10,}$/;
    return hpRegex.test(hp);
}

// Tampilkan error message
function showError(elementId, message) {
    const errorElement = document.getElementById(elementId);
    errorElement.textContent = message;
}

// Clear semua error messages
function clearErrors() {
    const errorElements = document.querySelectorAll('.error-message');
    errorElements.forEach(el => el.textContent = '');

    const inputs = document.querySelectorAll('.form-group input');
    inputs.forEach(input => input.classList.remove('error'));
}

// Render tabel kontak
function renderTable() {
    tableBody.innerHTML = '';

    if (contacts.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="4" class="empty-message">Belum ada kontak. Tambahkan kontak baru untuk memulai.</td></tr>';
        updateTotalCount();
        return;
    }

    contacts.forEach((contact, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${escapeHtml(contact.nama)}</td>
            <td>${escapeHtml(contact.email)}</td>
            <td>${escapeHtml(contact.hp)}</td>
            <td>
                <button class="btn btn-delete" data-index="${index}">Hapus</button>
            </td>
        `;

        // Add delete event listener
        const deleteBtn = row.querySelector('.btn-delete');
        deleteBtn.addEventListener('click', () => handleDeleteContact(index));

        tableBody.appendChild(row);
    });

    updateTotalCount();
}

// Hapus kontak
function handleDeleteContact(index) {
    contacts.splice(index, 1);
    renderTable();
}

// Update counter total kontak
function updateTotalCount() {
    const count = contacts.length;
    totalCountElement.textContent = `Total kontak: ${count}`;
}

// Escape HTML untuk mencegah XSS
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

// Initialize - render tabel kosong saat page load
renderTable();
